# docker-smmhub
Docker и другие технологии контейнеризации плотно входят в повседневную жизнь разработчика. Экономим время, силы и средства при разворачивании статичного сайта на nginx c автоматическим (и бесплатным) получением SSL сертификата от Letsencrypt.

Видео инструкция: https://www.youtube.com/watch?v=HXQ2eLwvoxY

***
Чат SmmHub: https://tttttt.me/smmhubchat

***
По всем вопросам пишите https://vk.me/smmhubru

***
Соцсети:

ВКонтакте — https://vk.com/smmhubru
Телеграмм — https://tttttt.me/smmhubru
Инстаграм — https://instagram.com/smmhubru
Фэйсбук — https://www.facebook.com/smmhubru

Первоисточник скрипта: https://medium.com/@pentacent/nginx-and-lets-encrypt-with-docker-in-less-than-5-minutes-b4b8a60d3a71
